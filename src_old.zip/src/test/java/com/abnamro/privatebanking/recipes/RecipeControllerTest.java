package com.abnamro.privatebanking.recipes;

import org.junit.jupiter.api.Test;

public class RecipeControllerTest {
    @Test
    void testCreateRceipe() {

    }
}
