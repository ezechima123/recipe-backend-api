package com.abnamro.privatebanking.recipes;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface RecipeService {

    RecipeDto addRecipe(NewRecipeDto newRecipeDto);

    RecipeDto updateRecipe(String id, RecipeDto recipeDto);

    void deleteRecipe(String recipeId);

    RecipeDto getRecipeById(String recipeId);

    Page<RecipeDto> getAllRecipes(Pageable pageable);

    List<RecipeDto> getRecipePagination(Integer pageNumber, Integer pageSize, String sort);

    List<RecipeDto> getRecipeByCriteria(SearchRequestDto searchRequestDto);

}