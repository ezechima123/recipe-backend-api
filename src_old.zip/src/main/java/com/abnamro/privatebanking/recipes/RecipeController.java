package com.abnamro.privatebanking.recipes;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abnamro.privatebanking.shared.ResponseHandler;

@RestController
@RequestMapping("/api")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @PostMapping("/v1/recipes")
    public ResponseEntity<?> createRecipe(@Valid @RequestBody NewRecipeDto createRecipeDTO) {
        RecipeDto recipeDto = recipeService.addRecipe(createRecipeDTO);
        return ResponseHandler.responseBuilder("Recipe Created Successfully", HttpStatus.CREATED, recipeDto);
    }

    @GetMapping("/v1/recipes/{recipeId}")
    public ResponseEntity<?> getRecipe(
            @PathVariable("recipeId") @NotNull(message = "Recipe ID must be Specified") String recipeId) {
        RecipeDto recipeDto = recipeService.getRecipeById(recipeId);
        return ResponseHandler.responseBuilder("Recipe retrieved Successfully", HttpStatus.OK, recipeDto);
    }

    @DeleteMapping("/v1/recipes/{recipeId}")
    public ResponseEntity<?> removeRecipe(
            @PathVariable("recipeId") @NotNull(message = "Recipe ID must be Specified") String recipeId) {
        recipeService.deleteRecipe(recipeId);
        return ResponseHandler.responseBuilder("Recipe deleted Successfully", HttpStatus.OK, null);
    }

    @PutMapping("/v1/recipes/{recipeId}")
    public ResponseEntity<?> updateRecipe(@PathVariable String id, @Valid @RequestBody RecipeDto recipeDto) {
        RecipeDto recipeDtoUpdated = recipeService.updateRecipe(id, recipeDto);
        return ResponseHandler.responseBuilder("Recipe updated Successfully", HttpStatus.OK, recipeDtoUpdated);
    }

    @GetMapping("/v1/recipes")
    public ResponseEntity<?> searchRecipeByCriteria(
            @RequestParam(required = false) Boolean isVegetarian,
            @RequestParam(required = false) Integer servings,
            @RequestParam(required = false) String ingredient,
            @RequestParam(required = false) String instruction,
            @RequestParam(required = false, defaultValue = "0") Integer pageNumber,
            @RequestParam(required = false, defaultValue = "50") Integer pageSize) {

        List<RecipeDto> recipeDtoList = recipeService.getRecipeByCriteria(
                SearchRequestDto.builder().isVegetarian(isVegetarian).servings(servings).ingredient(ingredient)
                        .instruction(instruction).pageNumber(pageNumber).pageSize(pageSize).build());

        return ResponseHandler.responseBuilder("Recipe retrieved Successfully", HttpStatus.OK, null);
    }

    @GetMapping("/v1/recipes")
    public ResponseEntity<?> searchRecipeV2(
            @RequestParam(required = false) Boolean isVegetarian,
            @RequestParam(required = false) Integer servings,
            @RequestParam(required = false) String ingredient,
            @RequestParam(required = false) String instruction,
            @RequestParam(required = false, defaultValue = "0") Integer page,
            @RequestParam(required = false, defaultValue = "50") Integer size) {

        List<RecipeDto> recipeDtoList = recipeService.getRecipeByCriteria(
                SearchRequestDto.builder().isVegetarian(isVegetarian).servings(servings).ingredient(ingredient)
                        .instruction(instruction).pageNumber(page).pageSize(size).build());

        return ResponseHandler.responseBuilder("Recipe retrieved Successfully", HttpStatus.OK, null);
    }

}