/*
 * Copyright 2023-2024 the original author or authors.
 *
 * Licensed under the ABN AMRO, Version 2.0 (the "License");
 */

package com.abnamro.privatebanking.recipes;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.abnamro.privatebanking.exception.ResourceNotFoundException;
import com.abnamro.privatebanking.shared.MessageUtil;

@Service
public class RecipeServiceImpl implements RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

    @Autowired
    private RecipeMapper recipeMapper;

    enum RecipeStatus {
        ACTIVE,
        DELETED
    }

    @Override
    public RecipeDto getRecipeById(String recipeId) {
        Optional<RecipeModel> recipeModelOptional = recipeRepository.findById(recipeId);
        if (!recipeModelOptional.isPresent()) {
            throw new ResourceNotFoundException(MessageUtil.RECIPE_NOT_FOUND(recipeId));
        }
        return recipeMapper.recipeModelToRecipeDTO(recipeModelOptional.get());
    }

    @Override
    public RecipeDto addRecipe(NewRecipeDto newRecipeDto) {
        LocalDateTime localDateTime = LocalDateTime.now();
        Optional<RecipeModel> recipeModelOptional = recipeRepository.findByReferenceId(newRecipeDto.getReferenceId());
        if (recipeModelOptional.isPresent()) {
            throw new ResourceNotFoundException(MessageUtil.RECIPE_ALREADY_EXIST(newRecipeDto.getReferenceId()));
        }
        RecipeModel recipeModel = recipeMapper.newRecipeDtoToRecipeModel(newRecipeDto);
        recipeModel.setCreatedDate(localDateTime);
        recipeModel.setModifiedDate(localDateTime);
        recipeModel.setStatus(RecipeStatus.ACTIVE.name());
        return recipeMapper.recipeModelToRecipeDTO(recipeRepository.save(recipeModel));
    }

    @Override
    public RecipeDto updateRecipe(String id, RecipeDto recipeDTO) {
        Optional<RecipeModel> recipeModelOptional = recipeRepository.findById(id);
        if (!recipeModelOptional.isPresent()) {
            throw new ResourceNotFoundException(MessageUtil.RECIPE_NOT_FOUND(id));
        }

        RecipeModel recipeModel = recipeModelOptional.get();
        recipeModel.setReferenceId(recipeDTO.getReferenceId());
        recipeModel.setTitle(recipeDTO.getTitle());
        recipeModel.setIngredientList(recipeDTO.getIngredientList());
        recipeModel.setInstructionList(recipeDTO.getInstructionList());
        recipeModel.setModifiedBy(recipeDTO.getModifiedBy());
        recipeModel.setModifiedDate(LocalDateTime.now());
        recipeModel.setComment(recipeDTO.getComment());
        return recipeMapper.recipeModelToRecipeDTO(recipeRepository.save(recipeModel));
    }

    @Override
    public void deleteRecipe(String recipeId) {

        Optional<RecipeModel> recipeModelOptional = recipeRepository.findById(recipeId);
        if (!recipeModelOptional.isPresent()) {
            throw new ResourceNotFoundException(MessageUtil.RECIPE_NOT_FOUND(recipeId));
        }

        RecipeModel recipeModel = recipeModelOptional.get();
        if (recipeModel.getStatus().equalsIgnoreCase(RecipeStatus.DELETED.name())) {
            throw new ResourceNotFoundException(MessageUtil.RECIPE_ALREADY_DELETED(recipeId));
        }
        recipeModel.setStatus(RecipeStatus.DELETED.name());
        recipeRepository.save(recipeModel);
    }

    @Override
    public Page<RecipeDto> getAllRecipes(Pageable pageable) {
        Page<RecipeModel> studentsPage = recipeRepository.findAll(pageable);

        List<RecipeDto> recipeDto = new ArrayList<>();
        Page<RecipeDto> recipeDtoPage = new PageImpl<>(recipeDto, pageable, 0);

        if (studentsPage != null && !studentsPage.isEmpty()) {

            studentsPage.getContent().forEach(recipeModel -> {
                recipeMapper.recipeModelToRecipeDTO(recipeModel);
            });
            recipeDtoPage = new PageImpl<>(recipeDto, pageable, studentsPage.getTotalElements());
        }
        return recipeDtoPage;
    }

    @Override
    public List<RecipeDto> getRecipePagination(Integer pageNumber, Integer pageSize, String sort) {
        Pageable pageable = null;
        if (sort != null) {
            pageable = PageRequest.of(pageNumber, pageSize, Sort.Direction.ASC, sort);
        } else {
            pageable = PageRequest.of(pageNumber, pageSize);
        }
        return recipeMapper.recipeModelListToRecipeDtoList(recipeRepository.findAll(pageable).getContent());

    }

    @Override
    public List<RecipeDto> getRecipeByCriteria(SearchRequestDto searchRequestDto) {

        Pageable pageable = PageRequest.of(searchRequestDto.getPageNumber(), searchRequestDto.getPageSize());

        recipeRepository.findRecipesByProperties2(false, 0, null, null, pageable);
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRecipeByCriteria'");
    }

}