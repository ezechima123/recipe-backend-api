package com.abnamro.privatebanking.recipes;

import java.util.List;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RecipeMapper {

    RecipeModel newRecipeDtoToRecipeModel(NewRecipeDto createRecipeRequestDTO);

    RecipeDto recipeModelToRecipeDTO(RecipeModel recipeModel);

    RecipeModel recipeModelSourceToRecipeDestModel(RecipeModel recipeEntity);

    List<RecipeDto> recipeModelListToRecipeDtoList(List<RecipeModel> recipeModelList);
}