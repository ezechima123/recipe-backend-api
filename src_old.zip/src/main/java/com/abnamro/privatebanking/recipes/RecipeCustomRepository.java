package com.abnamro.privatebanking.recipes;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface RecipeCustomRepository {
        public List<RecipeModel> findRecipesByProperties(boolean isVegetarian, int servings, String ingredientRef,
                        String instructionRef, Pageable page);

        public Page<RecipeModel> findRecipesByProperties2(boolean isVegetarian, int servings, String ingredientRef,
                        String instructionRef, Pageable page);

}
