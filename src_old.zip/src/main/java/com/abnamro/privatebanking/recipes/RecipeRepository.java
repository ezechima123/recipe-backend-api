/*
 * Copyright 2023-2024 the original author or authors.
 *
 * Licensed under the ABN AMRO, Version 2.0 (the "License");
 */

package com.abnamro.privatebanking.recipes;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

/**
 * Sample repository managing {@link Recipe} entities.
 *
 * @author Chima Emmanuel Ezeamama
 * @version 1.0
 * @since 6-6-2023
 */
public interface RecipeRepository extends MongoRepository<RecipeModel, String>, RecipeCustomRepository {
    public Page<RecipeModel> findAll(Pageable pageable);

    @Query("{'referenceId': ?0}")
    Optional<RecipeModel> findByReferenceId(String referenceId);

    @Query("  {$and: ["
            + "        {$and: ["
            + "                 {'isVegetarian': {$gte: :#{#searchRequestDto.isVegetarian}}},"
            + "               ]"
            + "        },"
            + "        {$or :["
            + "                {$expr: {$eq: [:#{#dto.country}, null]}},"
            + "                {'purchaseAddress.country': :#{#dto.country}}"
            + "               ]"
            + "         },"
            + "        {$or :["
            + "                {$expr: {$eq: [:#{#dto.paymentType}, []]}},"
            + "                {'purchasePayment.paymentType': {'$in': :#{#dto.paymentType}}}"
            + "               ]"
            + "         },"
            + "         {$or :["
            + "                {$expr: {$eq: [:#{#dto.product}, null]}},"
            + "                {'purchaseProducts.name': :#{#dto.product}}"
            + "               ]"
            + "          },"
            + "         {$and: ["
            + "                   {$or: ["
            + "                           {$expr: {$eq: [:#{#dto.getAfterDateTime()}, null]}},"
            + "                           {timestamp : {$gte : :#{#dto.getAfterDateTime()}}}"
            + "                         ]"
            + "                   },"
            + "                   {$or: ["
            + "                           {$expr: {$eq: [:#{#dto.getBeforeDateTime()}, null]}},"
            + "                           {timestamp : {$lte : :#{#dto.getBeforeDateTime()}}}"
            + "                         ]"
            + "                   }"
            + "                ]"
            + "         }"
            + "  ]"
            + "}")
    Page<RecipeModel> findAllWithFilters(SearchRequestDto searchRequestDto, Pageable pageable);
}