package com.abnamro.privatebanking.recipes;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "Recipes")
public class RecipeModel {
    @Id
    private String id;
    @Indexed
    private String referenceId;
    private String title;
    private boolean isVegetarian;
    private int servings;
    private List<String> ingredientList;
    private List<String> instructionList;
    private LocalDateTime createdDate;
    private String createdBy;
    private LocalDateTime modifiedDate;
    private String modifiedBy;
    private String status;
    private String comment;

}