package com.abnamro.privatebanking.recipes;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Repository;

import com.abnamro.privatebanking.shared.ValidationUtil;

@Repository
public class RecipeCustomRepositoryImpl implements RecipeCustomRepository {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public List<RecipeModel> findRecipesByProperties(boolean isVegetarian, int servings, String ingredientRef,
            String instructionRef, Pageable page) {

        final Query query = new Query().with(page);
        // query.fields().include("id").include("name");
        final List<Criteria> criteria = new ArrayList<>();
        criteria.add(Criteria.where("isVegetarian").is(isVegetarian));
        criteria.add(Criteria.where("servings").is(servings));

        if (ValidationUtil.isNotEmpty(ingredientRef))
            criteria.add(Criteria.where("ingredientRef").in(ingredientRef));
        if (ValidationUtil.isNotEmpty(instructionRef))
            criteria.add(Criteria.where("instructionRef").in(instructionRef));
        if (!criteria.isEmpty())
            query.addCriteria(new Criteria().andOperator(criteria.toArray(new Criteria[criteria.size()])));
        return mongoTemplate.find(query, RecipeModel.class);

    }

    @Override
    public Page<RecipeModel> findRecipesByProperties2(boolean isVegetarian, int servings, String ingredientRef,
            String instructionRef, Pageable page) {

        final Query query = new Query().with(page);
        query.fields().include("id").include("name");
        final List<Criteria> criteria = new ArrayList<>();
        criteria.add(Criteria.where("isVegetarian").is(isVegetarian));
        if (servings > 0)
            criteria.add(Criteria.where("servings").is(servings));
        if (ValidationUtil.isNotEmpty(ingredientRef))
            criteria.add(Criteria.where("ingredientRef").in(ingredientRef));
        if (ValidationUtil.isNotEmpty(instructionRef))
            criteria.add(Criteria.where("instructionRef").in(instructionRef));
        if (!criteria.isEmpty())
            query.addCriteria(new Criteria().andOperator(criteria.toArray(new Criteria[criteria.size()])));

        return PageableExecutionUtils.getPage(
                mongoTemplate.find(query, RecipeModel.class),
                page,
                () -> mongoTemplate.count(query.skip(0).limit(0), RecipeModel.class));

    }

}