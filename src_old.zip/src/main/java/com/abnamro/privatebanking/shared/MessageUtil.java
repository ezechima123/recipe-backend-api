package com.abnamro.privatebanking.shared;

public class MessageUtil {

    public static String RECIPE_NOT_FOUND(String id) {
        return "Recipe Id" + id + " not found!";
    }

    public static String RECIPE_ALREADY_DELETED(String id) {
        return "Recipe Id" + id + " already Deleted!";
    }

    public static String RECIPE_ALREADY_EXIST(String referenceId) {
        return "Recipe Reference " + referenceId + " already Exist!!";
    }

}