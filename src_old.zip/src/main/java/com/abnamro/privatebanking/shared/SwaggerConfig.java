package com.abnamro.privatebanking.shared;

public class SwaggerConfig {

}